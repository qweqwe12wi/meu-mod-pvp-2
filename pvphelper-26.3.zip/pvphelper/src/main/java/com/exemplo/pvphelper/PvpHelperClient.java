package com.exemplo.pvphelper;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.lwjgl.glfw.GLFW;

import java.util.Comparator;
import java.util.List;

/** Mod client-side: auto-clicker (G) e aim assist (H). Mojang mappings (MC 26.x). */
public class PvpHelperClient implements ClientModInitializer {
    private static final float SMOOTH_FACTOR = 0.20f; // suavização da mira
    private static final double RANGE = 5.0;          // raio de busca em blocos

    private static KeyMapping autoClickKey;
    private static KeyMapping aimAssistKey;
    private static boolean autoClickEnabled = false;
    private static boolean aimAssistEnabled = false;

    @Override
    public void onInitializeClient() {
        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath("pvphelper", "main"));

        autoClickKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.pvphelper.autoclicker", InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_G, category));
        aimAssistKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.pvphelper.aimassist", InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_H, category));

        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
    }

    private void onTick(Minecraft client) {
        LocalPlayer player = client.player;
        if (player == null || client.level == null || client.gameMode == null) return;

        // Alternância pelas teclas, com mensagem na Action Bar (acima da hotbar)
        while (autoClickKey.consumeClick()) {
            autoClickEnabled = !autoClickEnabled;
            client.gui.setOverlayMessage(
                    Component.literal("Auto-Clicker: " + (autoClickEnabled ? "ATIVADO" : "DESATIVADO")), false);
        }
        while (aimAssistKey.consumeClick()) {
            aimAssistEnabled = !aimAssistEnabled;
            client.gui.setOverlayMessage(
                    Component.literal("Aim Assist: " + (aimAssistEnabled ? "ATIVADO" : "DESATIVADO")), false);
        }

        if (client.screen != null) return; // não age com menus abertos

        if (aimAssistEnabled) runAimAssist(client, player);
        if (autoClickEnabled) runAutoClicker(client, player);
    }

    /** Ataca o alvo na mira quando o cooldown do ataque está em 100%. */
    private void runAutoClicker(Minecraft client, LocalPlayer player) {
        HitResult hit = client.hitResult;
        if (hit == null || hit.getType() != HitResult.Type.ENTITY) return;
        if (player.getAttackStrengthScale(0.0f) < 1.0f) return;

        EntityHitResult entityHit = (EntityHitResult) hit;
        client.gameMode.attack(player, entityHit.getEntity());
        player.swing(InteractionHand.MAIN_HAND);
    }

    /** Mira suavemente na cabeça da entidade viva mais próxima (até 5 blocos). */
    private void runAimAssist(Minecraft client, LocalPlayer player) {
        List<LivingEntity> nearby = client.level.getEntitiesOfClass(
                LivingEntity.class,
                player.getBoundingBox().inflate(RANGE),
                e -> e != player && e.isAlive() && player.distanceTo(e) <= RANGE);
        if (nearby.isEmpty()) return;

        LivingEntity target = nearby.stream()
                .min(Comparator.comparingDouble(player::distanceTo))
                .orElse(null);
        if (target == null) return;

        Vec3 from = player.getEyePosition();
        Vec3 to = target.getEyePosition(); // cabeça do alvo
        double dx = to.x - from.x;
        double dy = to.y - from.y;
        double dz = to.z - from.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);

        float targetYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(dy, horizontal));

        // Interpolação pelo caminho mais curto (wrapDegrees evita o "pulo" de 360°)
        float newYaw = player.getYRot() + Mth.wrapDegrees(targetYaw - player.getYRot()) * SMOOTH_FACTOR;
        float newPitch = player.getXRot() + (targetPitch - player.getXRot()) * SMOOTH_FACTOR;

        player.setYRot(newYaw);
        player.setXRot(Mth.clamp(newPitch, -90.0f, 90.0f));
    }
}
